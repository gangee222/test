import base64
import hashlib
import os
import struct
import sys
import tempfile
import unittest
import zipfile
from unittest import mock

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ANDROID_PY = os.path.join(ROOT, "app", "src", "main", "python")
sys.path.insert(0, ROOT)
sys.path.insert(0, ANDROID_PY)

import f1mobile_patcher as P  # noqa: E402
import runner  # noqa: E402


def _make_sample_apk(path, fake_lib=b"ORIG_LIB_DATA", lib_compress=zipfile.ZIP_DEFLATED):
    with zipfile.ZipFile(path, "w") as zf:
        info_arsc = zipfile.ZipInfo("resources.arsc", date_time=(1980, 1, 1, 0, 0, 0))
        info_arsc.compress_type = zipfile.ZIP_STORED
        zf.writestr(info_arsc, b"ARSC" * 17)

        info_so = zipfile.ZipInfo("lib/arm64-v8a/libother.so", date_time=(2024, 5, 1, 12, 0, 0))
        info_so.compress_type = zipfile.ZIP_STORED
        zf.writestr(info_so, b"\x7fELF" + b"\x00" * 64)

        info_lib = zipfile.ZipInfo(P.LIB_ENTRY, date_time=(2024, 5, 1, 12, 0, 0))
        info_lib.compress_type = lib_compress
        zf.writestr(info_lib, fake_lib)

        zf.writestr("META-INF/MANIFEST.MF", b"Manifest-Version: 1.0\r\n")
        zf.writestr("META-INF/UPLOAD.SF", b"Signature-Version: 1.0\r\n")
        zf.writestr("META-INF/UPLOAD.RSA", b"FAKECERT")
        zf.writestr("assets/config.json", b'{"offline":true}')


class PatcherTests(unittest.TestCase):
    def test_v1_sig_entry_detection(self):
        self.assertTrue(P.is_v1_sig_entry("META-INF/CERT.RSA"))
        self.assertTrue(P.is_v1_sig_entry("META-INF/upload.sf"))
        self.assertTrue(P.is_v1_sig_entry("META-INF/KEY0.EC"))
        self.assertTrue(P.is_v1_sig_entry("META-INF/MANIFEST.MF"))
        self.assertFalse(P.is_v1_sig_entry("META-INF/com/android/build/gradle/app-metadata.properties"))
        self.assertFalse(P.is_v1_sig_entry("assets/META-INF/MANIFEST.MF"))

    def test_dos_time_clamps_pre_1980(self):
        t, d = P._dos_time((1970, 0, 0, 25, 61, 61))
        self.assertGreaterEqual(d, 0)
        self.assertLessEqual(d, 0xFFFF)
        self.assertGreaterEqual(t, 0)
        self.assertLessEqual(t, 0xFFFF)

    def test_end_to_end_streaming_patch_alignment_and_v2_verify(self):
        fake_orig = b"ORIGINAL_IL2CPP_PAYLOAD_" * 1024
        fake_patched = b"PATCHED__IL2CPP_PAYLOAD_" * 1024
        orig_sha = hashlib.sha256(fake_orig).hexdigest()
        patched_sha = hashlib.sha256(fake_patched).hexdigest()

        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "in.apk")
            dst = os.path.join(tmp, "out.apk")
            _make_sample_apk(src, fake_lib=fake_orig, lib_compress=zipfile.ZIP_DEFLATED)

            with (
                mock.patch.object(P, "ORIGINAL_SHA256", orig_sha),
                mock.patch.object(P, "PATCHED_SHA256", patched_sha),
                mock.patch.object(P, "PATCHES", [(0, fake_patched)]),
            ):
                messages = []
                percentages = []

                class Progress:
                    def emit(self, msg):
                        messages.append(msg)

                    def onProgress(self, pct):
                        percentages.append(pct)

                    def isCancelled(self):
                        return False

                runner.run(src, dst, Progress())

                self.assertTrue(os.path.isfile(dst))
                self.assertFalse(os.path.exists(dst + ".tmp"))
                self.assertFalse(os.path.exists(dst + ".tmp.part"))
                self.assertEqual(percentages[0], 10)
                self.assertEqual(percentages[-1], 100)

                n, e, _ = P.load_key(base64.b64decode(P.KEY_PEM_B64).decode("utf-8"))
                P.verify_apk_v2(dst, expected_n=n, expected_e=e)

                with zipfile.ZipFile(dst, "r") as zf:
                    names = zf.namelist()
                    self.assertNotIn("META-INF/MANIFEST.MF", names)
                    self.assertNotIn("META-INF/UPLOAD.SF", names)
                    self.assertNotIn("META-INF/UPLOAD.RSA", names)
                    self.assertEqual(zf.read(P.LIB_ENTRY), fake_patched)

                with self.assertRaises(P.AlreadyPatchedError):
                    P.patch_library(fake_patched)

    def test_cancellation_cleans_up_temp_files(self):
        fake_orig = b"ORIGINAL_IL2CPP_PAYLOAD_" * 64
        fake_patched = b"PATCHED__IL2CPP_PAYLOAD_" * 64
        orig_sha = hashlib.sha256(fake_orig).hexdigest()
        patched_sha = hashlib.sha256(fake_patched).hexdigest()

        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "in.apk")
            dst = os.path.join(tmp, "out.apk")
            _make_sample_apk(src, fake_lib=fake_orig)

            class CancelProgress:
                def emit(self, _msg):
                    pass

                def onProgress(self, _pct):
                    pass

                def isCancelled(self):
                    return True

            with (
                mock.patch.object(P, "ORIGINAL_SHA256", orig_sha),
                mock.patch.object(P, "PATCHED_SHA256", patched_sha),
                mock.patch.object(P, "PATCHES", [(0, fake_patched)]),
            ):
                with self.assertRaises(P.CancelledError):
                    runner.run(src, dst, CancelProgress())

            self.assertFalse(os.path.exists(dst))
            self.assertFalse(os.path.exists(dst + ".tmp"))
            self.assertFalse(os.path.exists(dst + ".tmp.part"))

    def test_cli_help_and_missing_file(self):
        rc = P.main(["nonexistent.apk"])
        self.assertEqual(rc, 1)

    def test_inspect_apk_and_bundle_diagnostics(self):
        fake_orig = b"ORIGINAL_IL2CPP_PAYLOAD_" * 256
        fake_patched = b"PATCHED__IL2CPP_PAYLOAD_" * 256
        orig_sha = hashlib.sha256(fake_orig).hexdigest()
        patched_sha = hashlib.sha256(fake_patched).hexdigest()

        with tempfile.TemporaryDirectory() as tmp:
            orig_apk = os.path.join(tmp, "orig.apk")
            out_apk = os.path.join(tmp, "out.apk")
            bundle_xapk = os.path.join(tmp, "bundle.xapk")
            _make_sample_apk(orig_apk, fake_lib=fake_orig)

            with zipfile.ZipFile(bundle_xapk, "w") as zf:
                zf.writestr("com.codemasters.F1Mobile.apk", b"PK\x03\x04dummy")
                zf.writestr("config.arm64_v8a.apk", b"PK\x03\x04dummy")

            with (
                mock.patch.object(P, "ORIGINAL_SHA256", orig_sha),
                mock.patch.object(P, "PATCHED_SHA256", patched_sha),
                mock.patch.object(P, "PATCHES", [(0, fake_patched)]),
            ):
                orig_report = P.inspect_apk(orig_apk)
                self.assertEqual(orig_report["lib_state"], "ORIGINAL")
                self.assertGreater(len(orig_report["v1_entries"]), 0)
                self.assertFalse(orig_report["v2_patcher_key"])

                P.patch_apk(orig_apk, out_apk)
                patched_report = P.inspect_apk(out_apk)
                self.assertEqual(patched_report["lib_state"], "PATCHED")
                self.assertEqual(patched_report["v1_entries"], [])
                self.assertTrue(patched_report["v2_patcher_key"])
                self.assertEqual(patched_report["misaligned"], [])
                self.assertIn("ALREADY OFFLINE-PATCHED", P.format_inspection_report(patched_report))

                emitted = []

                class Collector:
                    def emit(self, msg):
                        emitted.append(msg)

                self.assertEqual(runner.inspect(out_apk, Collector()), "PATCHED")
                self.assertTrue(any("signed with offline patcher key" in m for m in emitted))
                self.assertEqual(len(runner.patcher_cert_sha256()), 64)

                bundle_report = P.inspect_apk(bundle_xapk)
                self.assertEqual(bundle_report["lib_state"], "MISSING")
                self.assertIn("XAPK/APKS", bundle_report["bundle_hint"])
                self.assertEqual(P.main(["--inspect", out_apk]), 0)
                self.assertEqual(P.main(["--inspect", bundle_xapk]), 1)

    def test_standalone_xapk_inspect_patch_and_extract_obb(self):
        fake_orig = b"ORIGINAL_IL2CPP_PAYLOAD_" * 256
        fake_patched = b"PATCHED__IL2CPP_PAYLOAD_" * 256
        orig_sha = hashlib.sha256(fake_orig).hexdigest()
        patched_sha = hashlib.sha256(fake_patched).hexdigest()

        with tempfile.TemporaryDirectory() as tmp:
            inner_apk = os.path.join(tmp, "base.apk")
            _make_sample_apk(inner_apk, fake_lib=fake_orig)
            with zipfile.ZipFile(inner_apk, "a") as zf:
                zf.writestr("AndroidManifest.xml", b"MANIFEST")

            xapk_path = os.path.join(tmp, "f1_5.4.11.xapk")
            obb_entry = "Android/obb/com.codemasters.F1Mobile/main.24001341.com.codemasters.F1Mobile.obb"
            with zipfile.ZipFile(xapk_path, "w") as zf:
                zf.write(inner_apk, arcname="base.apk")
                zf.writestr(obb_entry, b"OBB_DATA_BLOCK" * 128)

            out_dir = os.path.join(tmp, "out")
            os.makedirs(out_dir, exist_ok=True)
            out_apk = os.path.join(out_dir, "patched.apk")

            with (
                mock.patch.object(P, "ORIGINAL_SHA256", orig_sha),
                mock.patch.object(P, "PATCHED_SHA256", patched_sha),
                mock.patch.object(P, "PATCHES", [(0, fake_patched)]),
            ):
                report = P.inspect_apk(xapk_path)
                self.assertEqual(report["lib_state"], "ORIGINAL")
                self.assertEqual(report["xapk_source"], "base.apk")
                self.assertEqual(report["obb_entries"], [obb_entry])
                formatted = P.format_inspection_report(report)
                self.assertIn("XAPK inner   : base.apk", formatted)
                self.assertIn("main.24001341.com.codemasters.F1Mobile.obb", formatted)

                P.patch_apk(xapk_path, out_apk, extract_obb=True)
                self.assertTrue(os.path.isfile(out_apk))
                extracted_obb = os.path.join(out_dir, "main.24001341.com.codemasters.F1Mobile.obb")
                self.assertTrue(os.path.isfile(extracted_obb))

                n, e, _ = P.load_key(base64.b64decode(P.KEY_PEM_B64).decode("utf-8"))
                P.verify_apk_v2(out_apk, expected_n=n, expected_e=e)


if __name__ == "__main__":
    unittest.main()
