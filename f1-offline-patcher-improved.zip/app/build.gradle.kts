plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python") version "17.2.0"
}

android {
    namespace = "io.github.f1patcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.github.f1patcher"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // Every phone that can run F1 Mobile Racing is arm64-v8a.
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Debug key so `assembleRelease` works out of the box without a custom keystore.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        // Pure stdlib only (no pip dependencies needed).
        // If Gradle cannot locate python3 on PATH, set buildPython("/path/to/python3").
    }
}
