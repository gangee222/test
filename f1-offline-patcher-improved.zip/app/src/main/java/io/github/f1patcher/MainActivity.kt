package io.github.f1patcher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.chaquo.python.PyException
import com.chaquo.python.Python
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/**
 * One screen: pick an APK (or load the installed game), inspect or patch it with
 * f1mobile_patcher.py, save via SAF, and launch the installer.
 * Pure Android SDK — no AndroidX or layout XML.
 */
class MainActivity : Activity() {

    private companion object {
        const val PICK_APK = 1
        const val SAVE_APK = 2
        const val TARGET_PKG = "com.codemasters.F1Mobile"
        const val OUTPUT_FILENAME = "f1mobile-5.4.11-offline-patched.apk"
        const val INPUT_TEMP_NAME = "input.apk"
        const val EXTRA_BUFFER_BYTES = 64L * 1024L * 1024L
    }

    private data class GameInstallStatus(
        val installed: Boolean = false,
        val versionLabel: String = "",
        val signedWithPatcherKey: Boolean = false,
        val readableStandalonePath: String? = null,
        val isSplitApk: Boolean = false,
    )

    private class SessionState {
        var sourceUri: Uri? = null
        var sourceLocalPath: String? = null
        var sourceName: String? = null
        var sourceSizeBytes: Long = -1L
        var pendingOutput: File? = null
        var inspectTargetIsOutput: Boolean = false
        var lastSavedUri: Uri? = null
        var lastSavedName: String? = null
        var patcherCertSha256: String? = null
        var gameStatus: GameInstallStatus = GameInstallStatus()
        var isRunning: Boolean = false
        val cancelRequested = AtomicBoolean(false)
        var statusText: String = "Pick F1 Mobile Racing 5.4.11 base.apk (or .xapk)."
        var progressPercent: Int = 0
        var isIndeterminate: Boolean = false
        val logBuffer = StringBuilder()
        var activeActivity: MainActivity? = null
    }

    private data class Palette(
        val bg: Int,
        val surface: Int,
        val surfaceBorder: Int,
        val textPrimary: Int,
        val textSecondary: Int,
        val logBg: Int,
        val logText: Int,
        val accent: Int,
        val accentText: Int,
        val danger: Int,
        val success: Int,
        val warningText: Int,
        val mutedBtn: Int,
        val mutedBtnText: Int,
    )

    private val main = Handler(Looper.getMainLooper())
    private lateinit var session: SessionState
    private lateinit var palette: Palette

    private lateinit var statusView: TextView
    private lateinit var sourceBadgeView: TextView
    private lateinit var gameStatusView: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var pickButton: Button
    private lateinit var useInstalledButton: Button
    private lateinit var verifyButton: Button
    private lateinit var patchButton: Button
    private lateinit var cancelButton: Button
    private lateinit var saveButton: Button
    private lateinit var discardButton: Button
    private lateinit var installSavedButton: Button
    private lateinit var uninstallGameButton: Button
    private lateinit var openGameButton: Button
    private lateinit var copyLogButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        session = (lastNonConfigurationInstance as? SessionState) ?: SessionState().also {
            cleanupTempArtifacts()
            val existingOut = File(workDir(), OUTPUT_FILENAME)
            if (existingOut.isFile && existingOut.length() > 0L) {
                it.pendingOutput = existingOut
                it.inspectTargetIsOutput = true
                it.statusText = "Recovered unsaved patched APK. Tap Save or Inspect."
                it.progressPercent = 100
                it.logBuffer.append("Found unsaved patched APK (${formatMb(existingOut.length())}).\n")
            } else {
                it.logBuffer.append("Ready. Pick base.apk (extracted from .xapk) or a standalone .xapk.\n")
                it.logBuffer.append("Do not install the unpatched game first.\n")
            }
        }
        session.activeActivity = this

        palette = buildPalette()
        setContentView(buildUi())

        if (savedInstanceState == null) {
            handleIncomingIntent(intent)
        }
        refreshGameStatusAsync()
        syncUi()
    }

    override fun onResume() {
        super.onResume()
        refreshGameStatusAsync()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onRetainNonConfigurationInstance(): Any = session

    override fun onDestroy() {
        if (session.activeActivity === this) {
            session.activeActivity = null
        }
        super.onDestroy()
    }

    private fun buildPalette(): Palette {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return if (night) {
            Palette(
                bg = Color.parseColor("#0F1115"),
                surface = Color.parseColor("#171A21"),
                surfaceBorder = Color.parseColor("#2A2F3A"),
                textPrimary = Color.parseColor("#F1F5F9"),
                textSecondary = Color.parseColor("#94A3B8"),
                logBg = Color.parseColor("#0B0D11"),
                logText = Color.parseColor("#CBD5E1"),
                accent = Color.parseColor("#E11D48"),
                accentText = Color.WHITE,
                danger = Color.parseColor("#B91C1C"),
                success = Color.parseColor("#15803D"),
                warningText = Color.parseColor("#FBBF24"),
                mutedBtn = Color.parseColor("#232833"),
                mutedBtnText = Color.parseColor("#E2E8F0"),
            )
        } else {
            Palette(
                bg = Color.parseColor("#F8FAFC"),
                surface = Color.WHITE,
                surfaceBorder = Color.parseColor("#E2E8F0"),
                textPrimary = Color.parseColor("#0F172A"),
                textSecondary = Color.parseColor("#475569"),
                logBg = Color.parseColor("#0F172A"),
                logText = Color.parseColor("#E2E8F0"),
                accent = Color.parseColor("#DC2626"),
                accentText = Color.WHITE,
                danger = Color.parseColor("#B91C1C"),
                success = Color.parseColor("#15803D"),
                warningText = Color.parseColor("#B45309"),
                mutedBtn = Color.parseColor("#E2E8F0"),
                mutedBtnText = Color.parseColor("#0F172A"),
            )
        }
    }

    private fun roundedBox(fill: Int, stroke: Int? = null, radiusDp: Int = 12): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }
    }

    private fun styleButton(btn: Button, bg: Int, fg: Int) {
        btn.background = roundedBox(bg, radiusDp = 10)
        btn.setTextColor(fg)
        btn.isAllCaps = false
        btn.textSize = 13.5f
        btn.setTypeface(Typeface.DEFAULT_BOLD)
        btn.setPadding(dp(14), dp(11), dp(14), dp(11))
        btn.minHeight = dp(44)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(palette.bg)
            setPadding(dp(20), dp(20), dp(20), dp(16))
        }

        val title = TextView(this).apply {
            text = "F1 APK Patcher"
            textSize = 22f
            setTextColor(palette.textPrimary)
            setTypeface(Typeface.DEFAULT_BOLD)
        }

        val subtitle = TextView(this).apply {
            text = "Patches libil2cpp.so for F1 Mobile Racing 5.4.11 offline play and signs v2."
            textSize = 13f
            setTextColor(palette.textSecondary)
            setPadding(0, dp(4), 0, dp(12))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox(palette.surface, palette.surfaceBorder, radiusDp = 14)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        statusView = TextView(this).apply {
            textSize = 14f
            setTextColor(palette.textPrimary)
            setTypeface(Typeface.DEFAULT_BOLD)
        }

        sourceBadgeView = TextView(this).apply {
            textSize = 12f
            setTextColor(palette.textSecondary)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(0, dp(4), 0, dp(4))
        }

        gameStatusView = TextView(this).apply {
            textSize = 12f
            setTextColor(palette.textSecondary)
            setPadding(0, 0, 0, dp(10))
        }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }

        progressLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(palette.textSecondary)
            gravity = Gravity.END
            setPadding(0, dp(4), 0, dp(10))
        }

        val actionRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        pickButton = Button(this).apply {
            text = "1  Pick APK"
            styleButton(this, palette.mutedBtn, palette.mutedBtnText)
            setOnClickListener { pickApk() }
        }

        patchButton = Button(this).apply {
            text = "2  Patch APK"
            styleButton(this, palette.accent, palette.accentText)
            setOnClickListener { startPatch() }
        }

        cancelButton = Button(this).apply {
            text = "Cancel"
            styleButton(this, palette.danger, Color.WHITE)
            visibility = View.GONE
            setOnClickListener { requestCancel() }
        }

        actionRow1.addView(pickButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
            marginEnd = dp(8)
        })
        actionRow1.addView(patchButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        actionRow1.addView(cancelButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val utilityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }

        verifyButton = Button(this).apply {
            text = "Inspect APK"
            styleButton(this, palette.mutedBtn, palette.mutedBtnText)
            setOnClickListener { startInspect() }
        }

        useInstalledButton = Button(this).apply {
            text = "Use Installed"
            styleButton(this, palette.mutedBtn, palette.mutedBtnText)
            visibility = View.GONE
            setOnClickListener { loadInstalledGameApk() }
        }

        uninstallGameButton = Button(this).apply {
            text = "Uninstall Store"
            styleButton(this, palette.danger, Color.WHITE)
            visibility = View.GONE
            setOnClickListener { uninstallInstalledGame() }
        }

        openGameButton = Button(this).apply {
            text = "Open Game"
            styleButton(this, palette.success, Color.WHITE)
            visibility = View.GONE
            setOnClickListener { launchInstalledGame() }
        }

        utilityRow.addView(verifyButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        utilityRow.addView(useInstalledButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
            marginStart = dp(8)
        })
        utilityRow.addView(uninstallGameButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
            marginStart = dp(8)
        })
        utilityRow.addView(openGameButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply {
            marginStart = dp(8)
        })

        val saveRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }

        saveButton = Button(this).apply {
            text = "3  Save APK"
            styleButton(this, palette.success, Color.WHITE)
            setOnClickListener { askWhereToSave() }
        }

        discardButton = Button(this).apply {
            text = "Discard"
            styleButton(this, palette.mutedBtn, palette.mutedBtnText)
            setOnClickListener { discardPendingOutput() }
        }

        installSavedButton = Button(this).apply {
            text = "4  Install APK"
            styleButton(this, palette.success, Color.WHITE)
            visibility = View.GONE
            setOnClickListener { installLastSavedApk() }
        }

        saveRow.addView(saveButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 2f).apply {
            marginEnd = dp(8)
        })
        saveRow.addView(discardButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        card.addView(statusView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(sourceBadgeView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(gameStatusView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(progressBar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(progressLabel, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(actionRow1, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(utilityRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(saveRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        card.addView(installSavedButton, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        val logHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(6))
        }

        val logTitle = TextView(this).apply {
            text = "Activity Log"
            textSize = 13f
            setTypeface(Typeface.DEFAULT_BOLD)
            setTextColor(palette.textSecondary)
        }

        copyLogButton = Button(this).apply {
            text = "Copy Log"
            styleButton(this, palette.mutedBtn, palette.mutedBtnText)
            textSize = 12f
            minHeight = dp(34)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { copyLogToClipboard() }
        }

        logHeader.addView(logTitle, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        logHeader.addView(copyLogButton, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))

        logView = TextView(this).apply {
            textSize = 11.5f
            typeface = Typeface.MONOSPACE
            setTextColor(palette.logText)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        scroll = ScrollView(this).apply {
            background = roundedBox(palette.logBg, palette.surfaceBorder, radiusDp = 12)
            addView(logView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }

        root.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(subtitle, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(logHeader, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                view.setPadding(
                    dp(20) + bars.left,
                    dp(20) + bars.top,
                    dp(20) + bars.right,
                    dp(16) + bars.bottom
                )
                insets
            }
        }
        return root
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun workDir(): File = getExternalFilesDir(null) ?: filesDir

    private fun cleanupTempArtifacts() {
        val dir = workDir()
        dir.listFiles()?.forEach { f ->
            if (f.name == INPUT_TEMP_NAME || f.name.endsWith(".tmp") || f.name.endsWith(".part")) {
                f.delete()
            }
        }
    }

    private fun formatMb(bytes: Long): String {
        return if (bytes > 0L) String.format("%.1f MB", bytes / 1048576.0) else "unknown size"
    }

    private fun hasSourceSelection(): Boolean =
        session.sourceUri != null || session.sourceLocalPath != null

    private fun syncUi() {
        statusView.text = session.statusText
        sourceBadgeView.text = session.sourceName?.let { name ->
            if (session.sourceSizeBytes > 0L) "$name (${formatMb(session.sourceSizeBytes)})" else name
        } ?: "No APK selected"

        val gs = session.gameStatus
        if (!gs.installed) {
            gameStatusView.text = "Game not installed (ready to install patched APK)."
            gameStatusView.setTextColor(palette.textSecondary)
        } else if (gs.signedWithPatcherKey) {
            gameStatusView.text = "Installed: ${gs.versionLabel} (patcher key)."
            gameStatusView.setTextColor(palette.success)
        } else {
            val splitTag = if (gs.isSplitApk) ", split" else ""
            gameStatusView.text =
                "Installed: ${gs.versionLabel} (store key$splitTag — uninstall first)."
            gameStatusView.setTextColor(palette.warningText)
        }

        progressBar.isIndeterminate = session.isIndeterminate
        progressBar.progress = session.progressPercent
        progressLabel.text = if (session.isRunning || session.progressPercent > 0) {
            "${session.progressPercent}%"
        } else {
            ""
        }

        val hasOutput = session.pendingOutput?.let { it.isFile && it.length() > 0L } == true
        val canPatch = !session.isRunning && hasSourceSelection()
        val canVerify = !session.isRunning && (hasSourceSelection() || hasOutput)

        pickButton.isEnabled = !session.isRunning
        patchButton.visibility = if (session.isRunning) View.GONE else View.VISIBLE
        patchButton.isEnabled = canPatch
        patchButton.alpha = if (canPatch) 1f else 0.45f

        cancelButton.visibility = if (session.isRunning) View.VISIBLE else View.GONE
        cancelButton.isEnabled = session.isRunning && !session.cancelRequested.get()

        verifyButton.isEnabled = canVerify
        verifyButton.alpha = if (canVerify) 1f else 0.45f

        val showUseInstalled =
            !session.isRunning && !gs.signedWithPatcherKey && gs.readableStandalonePath != null
        useInstalledButton.visibility = if (showUseInstalled) View.VISIBLE else View.GONE

        val showUninstall = !session.isRunning && gs.installed && !gs.signedWithPatcherKey
        uninstallGameButton.visibility = if (showUninstall) View.VISIBLE else View.GONE

        val showOpenGame = !session.isRunning && gs.installed && gs.signedWithPatcherKey
        openGameButton.visibility = if (showOpenGame) View.VISIBLE else View.GONE

        saveButton.visibility = if (hasOutput && !session.isRunning) View.VISIBLE else View.GONE
        discardButton.visibility = if (hasOutput && !session.isRunning) View.VISIBLE else View.GONE

        val showInstallSaved = !session.isRunning && !hasOutput && session.lastSavedUri != null
        installSavedButton.visibility = if (showInstallSaved) View.VISIBLE else View.GONE
        if (showInstallSaved) {
            installSavedButton.text = "4  Install ${session.lastSavedName ?: "APK"}"
        }

        if (session.isRunning) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        logView.text = session.logBuffer.toString()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // --------------------------------------------------------- game check

    private fun refreshGameStatusAsync() {
        val activeSession = session
        Thread {
            if (activeSession.patcherCertSha256 == null) {
                activeSession.patcherCertSha256 = runCatching {
                    Python.getInstance()
                        .getModule("runner")
                        .callAttr("patcher_cert_sha256")
                        .toString()
                        .lowercase()
                }.getOrNull()
            }
            val detected = queryInstalledGameStatus(activeSession.patcherCertSha256)
            main.post {
                activeSession.gameStatus = detected
                activeSession.activeActivity?.syncUi()
            }
        }.start()
    }

    private fun queryInstalledGameStatus(patcherCertSha256: String?): GameInstallStatus {
        val pkgInfo: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(
                    TARGET_PKG,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_SIGNING_CERTIFICATES.toLong())
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(
                    TARGET_PKG,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(
                    TARGET_PKG,
                    PackageManager.GET_SIGNATURES
                )
            }
        } catch (_: PackageManager.NameNotFoundException) {
            return GameInstallStatus(installed = false)
        } catch (_: Exception) {
            return GameInstallStatus(installed = false)
        }

        val verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.versionCode.toLong()
        }
        val verName = pkgInfo.versionName ?: "?"
        val versionLabel = "v$verName ($verCode)"

        val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pkgInfo.signingInfo
            info?.apkContentsSigners?.firstOrNull()?.toByteArray()
                ?: info?.signingCertificateHistory?.firstOrNull()?.toByteArray()
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.signatures?.firstOrNull()?.toByteArray()
        }

        val certSha = sigBytes?.let { bytes ->
            MessageDigest.getInstance("SHA-256")
                .digest(bytes)
                .joinToString("") { "%02x".format(it) }
        }
        val matchesPatcher =
            patcherCertSha256 != null && certSha != null && certSha == patcherCertSha256

        val appInfo = pkgInfo.applicationInfo
        val splits = appInfo?.splitPublicSourceDirs
        val isSplit = splits != null && splits.isNotEmpty()
        val publicDir = appInfo?.publicSourceDir
        val readableStandalone = if (!isSplit && publicDir != null) {
            val f = File(publicDir)
            if (f.isFile && f.canRead()) publicDir else null
        } else {
            null
        }

        return GameInstallStatus(
            installed = true,
            versionLabel = versionLabel,
            signedWithPatcherKey = matchesPatcher,
            readableStandalonePath = readableStandalone,
            isSplitApk = isSplit,
        )
    }

    private fun loadInstalledGameApk() {
        val path = session.gameStatus.readableStandalonePath ?: return
        val file = File(path)
        if (!file.isFile || !file.canRead()) {
            Toast.makeText(this, "Installed APK is not directly readable; pick it manually.", Toast.LENGTH_SHORT).show()
            return
        }
        session.sourceUri = null
        session.sourceLocalPath = path
        session.sourceName = "Installed F1 Mobile (${session.gameStatus.versionLabel})"
        session.sourceSizeBytes = file.length()
        session.inspectTargetIsOutput = false
        session.lastSavedUri = null
        session.lastSavedName = null
        session.progressPercent = 0
        session.statusText = "Loaded installed APK. Tap 2  Patch APK or Inspect APK."
        appendLog("Loaded installed APK: $path (${formatMb(file.length())})")
        syncUi()
    }

    private fun uninstallInstalledGame() {
        val uninstallIntent = Intent(
            Intent.ACTION_DELETE,
            Uri.parse("package:$TARGET_PKG")
        )
        runCatching { startActivity(uninstallIntent) }
            .onFailure {
                Toast.makeText(this, "Could not launch uninstaller.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun launchInstalledGame() {
        val launchIntent = packageManager.getLaunchIntentForPackage(TARGET_PKG)
        if (launchIntent == null) {
            Toast.makeText(this, "Game launcher activity not found.", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching { startActivity(launchIntent) }
            .onFailure {
                Toast.makeText(this, "Could not open F1 Mobile Racing.", Toast.LENGTH_SHORT).show()
            }
    }

    // --------------------------------------------------------------- intents

    private fun handleIncomingIntent(incoming: Intent?) {
        if (incoming == null || session.isRunning) return
        val uri: Uri? = when (incoming.action) {
            Intent.ACTION_VIEW -> incoming.data
            Intent.ACTION_SEND -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    incoming.getParcelableExtra(Intent.EXTRA_STREAM)
                }
            }
            else -> null
        }
        if (uri != null) {
            selectSourceUri(uri)
        }
    }

    private fun pickApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/vnd.android.package-archive",
                    "application/octet-stream",
                    "application/zip",
                )
            )
        }
        startActivityForResult(intent, PICK_APK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        when (requestCode) {
            PICK_APK -> {
                if (resultCode == RESULT_OK && uri != null) {
                    selectSourceUri(uri)
                }
            }
            SAVE_APK -> {
                if (resultCode == RESULT_OK && uri != null) {
                    saveTo(uri)
                } else {
                    appendLog("Save cancelled. Tap '3  Save APK' whenever ready.")
                    session.statusText = "Patched APK is ready to save."
                    syncUi()
                }
            }
        }
    }

    private fun selectSourceUri(uri: Uri) {
        val (name, size) = queryMeta(uri)
        session.sourceUri = uri
        session.sourceLocalPath = null
        session.sourceName = name
        session.sourceSizeBytes = size
        session.inspectTargetIsOutput = false
        session.lastSavedUri = null
        session.lastSavedName = null
        session.progressPercent = 0
        session.statusText = "Ready to patch or inspect $name."
        appendLog("Selected: $name (${formatMb(size)})")
        syncUi()
    }

    private fun queryMeta(uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment ?: "selected.apk"
        var size = -1L
        runCatching {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0 && !cursor.isNull(nameIdx)) name = cursor.getString(nameIdx)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
                }
            }
        }
        if (size <= 0L) {
            size = runCatching {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            }.getOrDefault(-1L)
        }
        return name to size
    }

    // --------------------------------------------------------- inspect/verify

    private fun startInspect() {
        if (session.isRunning) return
        val pendingFile = session.pendingOutput?.takeIf { it.isFile && it.length() > 0L }
        val localSource = session.sourceLocalPath?.let { File(it) }?.takeIf { it.isFile && it.canRead() }
        val uri = session.sourceUri
        val inspectPendingFirst = session.inspectTargetIsOutput && pendingFile != null

        if (pendingFile == null && localSource == null && uri == null) return

        session.cancelRequested.set(false)
        session.isRunning = true
        session.isIndeterminate = true
        session.statusText = "Inspecting APK ..."
        syncUi()

        val activeSession = session
        Thread {
            var copiedTemp: File? = null
            try {
                val targetPath: String = when {
                    inspectPendingFirst -> pendingFile!!.absolutePath
                    localSource != null -> localSource.absolutePath
                    uri != null -> {
                        val tmp = File(workDir(), INPUT_TEMP_NAME)
                        copiedTemp = tmp
                        postLog(activeSession, "Reading selected APK for inspection ...")
                        copyUriAndValidateZip(uri, tmp, activeSession)
                        tmp.absolutePath
                    }
                    else -> pendingFile!!.absolutePath
                }

                val libState = Python.getInstance().getModule("runner").callAttr(
                    "inspect",
                    targetPath,
                    ProgressBridge(activeSession),
                ).toString()

                main.post {
                    activeSession.isRunning = false
                    activeSession.isIndeterminate = false
                    activeSession.statusText = when (libState) {
                        "ORIGINAL" -> "Inspect: original 5.4.11 APK (ready to patch)."
                        "PATCHED" -> "Inspect: already offline-patched."
                        "MISSING" -> "Inspect: missing arm64 libil2cpp.so (see log)."
                        else -> "Inspect: unsupported APK version (see log)."
                    }
                    activeSession.activeActivity?.syncUi()
                }
            } catch (e: Exception) {
                val raw = (e as? PyException)?.message ?: e.message ?: e.toString()
                main.post {
                    activeSession.isRunning = false
                    activeSession.isIndeterminate = false
                    activeSession.statusText = "Inspection failed."
                    appendToSession(activeSession, "INSPECT ERROR: ${raw.trim()}")
                    activeSession.activeActivity?.syncUi()
                }
            } finally {
                copiedTemp?.delete()
            }
        }.start()
    }

    // ----------------------------------------------------------------- patch

    private fun startPatch() {
        if (!hasSourceSelection() || session.isRunning) return

        session.logBuffer.clear()
        session.pendingOutput?.delete()
        session.pendingOutput = null
        session.inspectTargetIsOutput = false
        session.lastSavedUri = null
        session.lastSavedName = null
        session.cancelRequested.set(false)
        session.isRunning = true
        session.isIndeterminate = false
        session.progressPercent = 2
        session.statusText = "Checking storage and APK header ..."
        syncUi()

        val uri = session.sourceUri
        val localPath = session.sourceLocalPath
        val activeSession = session
        Thread {
            val dir = workDir()
            val input = File(dir, INPUT_TEMP_NAME)
            val result = File(dir, OUTPUT_FILENAME)
            var copiedInput = false
            try {
                cleanupTempArtifacts()
                val knownSize = activeSession.sourceSizeBytes
                if (knownSize > 0L) {
                    val avail = StatFs(dir.absolutePath).availableBytes
                    val isLargeBundle = localPath == null && (
                        activeSession.sourceName?.endsWith(".xapk", ignoreCase = true) == true ||
                            knownSize > 256L * 1024L * 1024L
                        )
                    val needed = when {
                        localPath != null -> (knownSize * 12L) / 10L + EXTRA_BUFFER_BYTES
                        isLargeBundle -> knownSize + 220L * 1024L * 1024L
                        else -> (knownSize * 22L) / 10L + EXTRA_BUFFER_BYTES
                    }
                    if (avail < needed) {
                        throw IllegalStateException(
                            "Not enough free storage: need ~${formatMb(needed)}, have ${formatMb(avail)}"
                        )
                    }
                }

                val srcPath: String = if (localPath != null) {
                    validateZipMagic(File(localPath))
                    postLog(activeSession, "Using installed APK (${formatMb(File(localPath).length())}).")
                    localPath
                } else {
                    copiedInput = true
                    postLog(activeSession, "Copying selected file ...")
                    copyUriAndValidateZip(uri!!, input, activeSession)
                    postLog(activeSession, "Input verified (${formatMb(input.length())}).")
                    input.absolutePath
                }

                postProgress(activeSession, 10, "Patching libil2cpp.so ...")

                Python.getInstance().getModule("runner").callAttr(
                    "run",
                    srcPath,
                    result.absolutePath,
                    ProgressBridge(activeSession),
                )

                activeSession.pendingOutput = result
                activeSession.inspectTargetIsOutput = true
                main.post {
                    activeSession.isRunning = false
                    activeSession.progressPercent = 100
                    activeSession.statusText = "Patched & verified. Choose where to save."
                    activeSession.activeActivity?.let { act ->
                        act.syncUi()
                        act.askWhereToSave()
                    }
                }
            } catch (e: Exception) {
                result.delete()
                val raw = (e as? PyException)?.message ?: e.message ?: e.toString()
                val wasCancelled = activeSession.cancelRequested.get() ||
                    raw.contains("Cancelled", ignoreCase = true)
                main.post {
                    activeSession.isRunning = false
                    activeSession.progressPercent = 0
                    activeSession.statusText = if (wasCancelled) "Cancelled." else "Patching failed."
                    appendToSession(
                        activeSession,
                        if (wasCancelled) "Cancelled by user." else "ERROR: ${raw.trim()}"
                    )
                    activeSession.activeActivity?.syncUi()
                }
            } finally {
                if (copiedInput) input.delete()
                cleanupTempArtifacts()
            }
        }.start()
    }

    private fun requestCancel() {
        if (!session.isRunning) return
        session.cancelRequested.set(true)
        session.statusText = "Cancelling ..."
        appendLog("Cancellation requested ...")
        syncUi()
    }

    private fun validateZipMagic(file: File) {
        if (!file.isFile || file.length() < 4L) {
            throw IllegalArgumentException("Selected file is empty or unreadable.")
        }
        val header = ByteArray(4)
        file.inputStream().use {
            if (it.read(header) < 4) {
                throw IllegalArgumentException("Cannot read APK header.")
            }
        }
        if (header[0] != 0x50.toByte() ||
            header[1] != 0x4B.toByte() ||
            header[2] != 0x03.toByte() ||
            header[3] != 0x04.toByte()
        ) {
            throw IllegalArgumentException("Selected file is not a valid APK/ZIP archive (missing PK header).")
        }
    }

    private fun copyUriAndValidateZip(uri: Uri, destination: File, activeSession: SessionState) {
        val total = activeSession.sourceSizeBytes
        val stream = contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Cannot read the selected file")
        stream.use { from ->
            destination.outputStream().use { to ->
                val buffer = ByteArray(1 shl 20)
                var done = 0L
                var checkedMagic = false
                var lastPct = -1
                while (true) {
                    if (activeSession.cancelRequested.get()) {
                        throw InterruptedException("Cancelled by user.")
                    }
                    val count = from.read(buffer)
                    if (count < 0) break
                    if (!checkedMagic) {
                        if (count < 4 ||
                            buffer[0] != 0x50.toByte() ||
                            buffer[1] != 0x4B.toByte() ||
                            buffer[2] != 0x03.toByte() ||
                            buffer[3] != 0x04.toByte()
                        ) {
                            throw IllegalArgumentException(
                                "Selected file is not a valid APK/ZIP archive (missing PK header)."
                            )
                        }
                        checkedMagic = true
                    }
                    to.write(buffer, 0, count)
                    done += count
                    if (total > 0L) {
                        val copyPct = ((done * 10L) / total).toInt().coerceIn(0, 10)
                        if (copyPct != lastPct) {
                            lastPct = copyPct
                            postProgress(activeSession, copyPct, "Reading input (${copyPct * 10}%) ...")
                        }
                    }
                }
                if (!checkedMagic) {
                    throw IllegalArgumentException("Selected file is empty.")
                }
            }
        }
    }

    // --------------------------------------------------------- save & install

    private fun askWhereToSave() {
        val file = session.pendingOutput
        if (file == null || !file.isFile) {
            Toast.makeText(this, "No patched APK available to save.", Toast.LENGTH_SHORT).show()
            syncUi()
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_TITLE, OUTPUT_FILENAME)
        }
        startActivityForResult(intent, SAVE_APK)
    }

    private fun saveTo(uri: Uri) {
        val file = session.pendingOutput ?: return
        session.isRunning = true
        session.statusText = "Saving patched APK ..."
        syncUi()

        val activeSession = session
        Thread {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { to ->
                    file.inputStream().use { it.copyTo(to, 1 shl 20) }
                } ?: throw IllegalStateException("Cannot write to the selected location")

                val savedName = queryMeta(uri).first
                val sizeLabel = formatMb(file.length())
                file.delete()
                activeSession.pendingOutput = null
                activeSession.inspectTargetIsOutput = false
                activeSession.lastSavedUri = uri
                activeSession.lastSavedName = savedName
                main.post {
                    activeSession.isRunning = false
                    activeSession.statusText = "Saved $savedName ($sizeLabel)."
                    appendToSession(
                        activeSession,
                        "Saved $savedName ($sizeLabel).\n" +
                            "Next steps:\n" +
                            "  1. Tap '4  Install' to install the patched APK.\n" +
                            "  2. Open the game once until the loading logo appears, then close it completely (creates Android/obb/$TARGET_PKG/).\n" +
                            "  3. Copy the .obb file into Internal Storage/Android/obb/$TARGET_PKG/ using ZArchiver, then launch."
                    )
                    activeSession.activeActivity?.syncUi()
                }
            } catch (e: Exception) {
                main.post {
                    activeSession.isRunning = false
                    activeSession.statusText = "Save failed (patched APK kept; tap Save to retry)."
                    appendToSession(activeSession, "ERROR saving: ${e.message}")
                    activeSession.activeActivity?.syncUi()
                }
            }
        }.start()
    }

    private fun installLastSavedApk() {
        val uri = session.lastSavedUri ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(
                this,
                "Allow 'Install unknown apps' for F1 APK Patcher, then tap Install again.",
                Toast.LENGTH_LONG
            ).show()
            val settingsIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:$packageName")
            )
            runCatching { startActivity(settingsIntent) }
            return
        }

        if (session.gameStatus.installed && !session.gameStatus.signedWithPatcherKey) {
            appendLog("Note: store build is still installed; uninstall it if Android blocks the install.")
        }

        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { startActivity(installIntent) }
            .onFailure {
                Toast.makeText(
                    this,
                    "Could not open package installer; install the saved APK from your Files app.",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun discardPendingOutput() {
        session.pendingOutput?.delete()
        session.pendingOutput = null
        session.inspectTargetIsOutput = false
        session.progressPercent = 0
        session.statusText = "Discarded pending output."
        appendLog("Discarded temporary patched APK.")
        syncUi()
    }

    private fun copyLogToClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("F1 Patcher Log", session.logBuffer.toString()))
        Toast.makeText(this, "Log copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    // -------------------------------------------------------------- progress

    private inner class ProgressBridge(private val target: SessionState) {
        fun emit(message: String) = postLog(target, message)
        fun onProgress(percent: Int) = postProgress(target, percent.coerceIn(0, 100), null)
        fun isCancelled(): Boolean = target.cancelRequested.get()
    }

    private fun postLog(target: SessionState, line: String) {
        main.post {
            appendToSession(target, line)
            target.activeActivity?.let {
                it.logView.text = target.logBuffer.toString()
                it.scroll.post { it.scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
    }

    private fun postProgress(target: SessionState, percent: Int, status: String?) {
        main.post {
            target.progressPercent = percent
            if (status != null) target.statusText = status
            target.activeActivity?.let {
                it.progressBar.progress = percent
                it.progressLabel.text = "$percent%"
                if (status != null) it.statusView.text = status
            }
        }
    }

    private fun appendToSession(target: SessionState, line: String) {
        target.logBuffer.append(line).append('\n')
    }

    private fun appendLog(line: String) {
        appendToSession(session, line)
    }
}
