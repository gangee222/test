"""Android / Chaquopy entry point.

Delegates streaming ZIP rebuild, 4096-byte .so alignment, v1 signature
stripping, APK Signature Scheme v2 signing, and self-verification directly to
`f1mobile_patcher` so PC and Android share one canonical implementation.
"""

import base64
import hashlib
import f1mobile_patcher as P


def patcher_cert_sha256():
    """Return lowercase SHA-256 hex digest of the offline patcher signing certificate."""
    return hashlib.sha256(base64.b64decode(P.CERT_DER_B64)).hexdigest()


def inspect(src, progress=None):
    """Inspect `src` APK non-destructively and return its lib_state string."""
    report = P.inspect_apk(src)
    text = P.format_inspection_report(report)
    if progress is not None:
        for line in text.splitlines():
            try:
                progress.emit(line)
            except Exception:
                pass
    return report["lib_state"]


def run(src, dst, progress=None):
    """Patch `src` APK and atomically write signed result to `dst`.

    `progress` is an optional Java/Kotlin callback object implementing:
      - emit(message: str)
      - onProgress(percent: int)   [optional]
      - isCancelled() -> bool      [optional]
    """

    def say(message):
        if progress is not None:
            try:
                progress.emit(str(message))
                return
            except Exception:
                pass
        print(message)

    def on_entry_progress(index, total):
        if progress is None or total <= 0:
            return
        pct = 25 + int((index * 63) / total)
        try:
            progress.onProgress(pct)
        except Exception:
            pass

    def is_cancelled():
        if progress is None:
            return False
        try:
            return bool(progress.isCancelled())
        except Exception:
            return False

    if progress is not None:
        try:
            progress.onProgress(10)
        except Exception:
            pass

    P.patch_apk(
        src,
        dst,
        say=say,
        progress_cb=on_entry_progress,
        cancel_check=is_cancelled,
        verify=True,
    )

    if progress is not None:
        try:
            progress.onProgress(100)
        except Exception:
            pass

    return dst
